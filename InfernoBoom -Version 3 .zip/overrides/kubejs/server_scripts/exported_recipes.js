ServerEvents.recipes(event => {

    event.shaped(
            Item.of('cataclysm:the_incinerator'),
            [
                    'ABA',
                    'BAB',
                    'BCB'
            ],
            {
                    B: 'cataclysm:ignitium_ingot',
                    A: 'cataclysm:witherite_ingot',
                    C: 'minecraft:netherite_sword'
            }
    )
    event.shaped(
            Item.of('minecraft:trident'),
            [
                    'ABA',
                    ' C ',
                    ' C '
            ],
            {
                    A: 'minecraft:totem_of_undying',
                    B: 'minecraft:fishing_rod',
                    C: 'minecraft:stone_sword'
            }
    )
    event.shaped(
            Item.of('cataclysm:infernal_forge'),
            [
                    'AAA',
                    'ABA',
                    'AAA'
            ],
            {
                    B: 'minecraft:diamond_axe',
                    A: 'cataclysm:lava_power_cell'
            }
    )
});
